namespace {:namespace};

class {:class} extends \lithium\data\Model {

	public $validates = [];
}