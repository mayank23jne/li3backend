<?php

return [
	1 => [
		'_id' => 1,
		'gallery' => [
			'_id' => 1,
			'name' => 'Foo Gallery',
			'active' => true,
			'created' => 1182373347,
			'modified' => 1260830169,
		],
		'image' => 'someimage.png',
		'title' => 'Amiga 1200',
		'created' => 1306060993,
		'modified' => 1354300690,
	],
	2 => [
		'_id' => 2,
		'gallery' => 
		[
			'_id' => 1,
			'name' => 'Foo Gallery',
			'active' => true,
			'created' => 1182373347,
			'modified' => 1260830169,
		],
		'image' => 'image.jpg',
		'title' => 'Srinivasa Ramanujan',
		'created' => 1231144767,
		'modified' => 1237009327,
	],
	3 => [
		'_id' => 3,
		'gallery' => [
			'_id' => 1,
			'name' => 'Foo Gallery',
			'active' => true,
			'created' => 1182373347,
			'modified' => 1260830169,
		],
		'image' => 'photo.jpg',
		'title' => 'Las Vegas',
		'created' => 1281568323,
		'modified' => 1285303514,
	],
];

?>