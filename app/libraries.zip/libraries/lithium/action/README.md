# action

The `action` namespace relies on `lithium\net\http`, and includes classes required to route and dispatch HTTP requests.
