{:heading}Affected Tests{:end}
<?php
	foreach ($data as $class => $test) {
		if ($test) {
			echo "{$test}\n";
		}
	}
?>